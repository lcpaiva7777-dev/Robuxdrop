// Backend mínimo para evitar o bloqueio CORS ao abrir a página.
const express = require("express");
const path = require("path");

const app = express();
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/roblox", async (req, res) => {
  const username = String(req.query.username || "").trim();
  if (!username) return res.status(400).json({error:"MISSING_USERNAME"});

  try {
    const userResponse = await fetch("https://users.roblox.com/v1/usernames/users", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({
        usernames: [username],
        excludeBannedUsers: false
      })
    });

    if (!userResponse.ok)
      return res.status(502).json({error:"ROBLOX_USERS_API"});

    const users = await userResponse.json();
    const user = users.data?.find(
      u => u.name.toLowerCase() === username.toLowerCase()
    );

    if (!user) return res.status(404).json({error:"NOT_FOUND"});

    const avatarResponse = await fetch(
      "https://thumbnails.roblox.com/v1/users/avatar" +
      "?userIds=" + encodeURIComponent(user.id) +
      "&size=420x420&format=Png&isCircular=false"
    );

    if (!avatarResponse.ok)
      return res.status(502).json({error:"ROBLOX_AVATAR_API"});

    const avatarData = await avatarResponse.json();
    const avatar = avatarData.data?.[0]?.imageUrl;

    if (!avatar) return res.status(502).json({error:"NO_AVATAR"});

    res.json({
      id: user.id,
      username: user.name,
      displayName: user.displayName,
      avatar
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({error:"SERVER_ERROR"});
  }
});

app.listen(process.env.PORT || 3000, () =>
  console.log("Servidor em http://localhost:" + (process.env.PORT || 3000))
);
